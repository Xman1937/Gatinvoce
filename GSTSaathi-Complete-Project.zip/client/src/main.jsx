import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {LayoutDashboard,Users,Package,ReceiptIndianRupee,BarChart3,LogOut,Plus,Search,Menu,X,CreditCard} from 'lucide-react';
import './styles.css';

const API=import.meta.env.VITE_API_URL||'http://localhost:5000/api';
const money=v=>'₹'+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2});
async function api(path,opt={}){
 const token=localStorage.getItem('gst_token');
 const r=await fetch(API+path,{...opt,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...(opt.headers||{})}});
 const data=await r.json().catch(()=>({}));
 if(!r.ok) throw new Error(data.error||'Request failed');
 return data;
}

function Auth({onLogin}){
 const [mode,setMode]=useState('login'),[form,setForm]=useState({}),[err,setErr]=useState(''),[busy,setBusy]=useState(false);
 const submit=async e=>{e.preventDefault();setBusy(true);setErr('');try{
  const data=await api(mode==='login'?'/auth/login':'/auth/signup',{method:'POST',body:JSON.stringify(form)});
  localStorage.setItem('gst_token',data.token);onLogin(data);
 }catch(e){setErr(e.message)}finally{setBusy(false)}};
 return <div className="auth"><div className="authCard"><div className="brand"><span>₹</span> GSTSaathi</div><h1>{mode==='login'?'Welcome back':'Start your business'}</h1><p>{mode==='login'?'Login to your billing dashboard.':'Create your 30-day free account.'}</p>
 <form onSubmit={submit}>{mode==='signup'&&<><input required placeholder="Business name" onChange={e=>setForm({...form,businessName:e.target.value})}/><input required placeholder="Your name" onChange={e=>setForm({...form,name:e.target.value})}/><input placeholder="GSTIN" onChange={e=>setForm({...form,gstin:e.target.value})}/></>}
 <input required type="email" placeholder="Email" onChange={e=>setForm({...form,email:e.target.value})}/><input required type="password" minLength="6" placeholder="Password" onChange={e=>setForm({...form,password:e.target.value})}/>
 {err&&<div className="error">{err}</div>}<button disabled={busy} className="primary">{busy?'Please wait...':mode==='login'?'Login':'Create account'}</button></form>
 <button className="link" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'Create new account':'Already have an account? Login'}</button></div></div>
}

function App(){
 const [data,setData]=useState(null),[tab,setTab]=useState('dashboard'),[open,setOpen]=useState(false);
 const logout=()=>{localStorage.removeItem('gst_token');setData(null)};
 if(!localStorage.getItem('gst_token')||!data)return <Auth onLogin={setData}/>;
 return <div className="app"><aside className={open?'show':''}><div className="brand"><span>₹</span> GSTSaathi</div>{[['dashboard','Dashboard',LayoutDashboard],['customers','Customers',Users],['products','Inventory',Package],['invoices','Invoices',ReceiptIndianRupee],['reports','Reports',BarChart3],['billing','Billing',CreditCard]].map(([id,n,I])=><button className={tab===id?'nav active':'nav'} onClick={()=>{setTab(id);setOpen(false)}}><I size={19}/>{n}</button>)}<button className="nav logout" onClick={logout}><LogOut size={19}/>Logout</button></aside><main><header className="top"><button className="menu" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button><div><b>{data.business?.name||'Business'}</b><small>{data.user?.role}</small></div></header><Content tab={tab}/></main></div>
}

function Content({tab}){
 const [stats,setStats]=useState({}),[rows,setRows]=useState([]),[q,setQ]=useState(''),[show,setShow]=useState(false);
 const load=async()=>{try{if(tab==='dashboard')setStats(await api('/dashboard'));if(['customers','products','invoices'].includes(tab))setRows(await api('/'+tab));if(tab==='reports')setStats(await api('/reports/summary'));}catch(e){alert(e.message)}};
 useEffect(()=>{load()},[tab]);
 if(tab==='dashboard')return <section className="content"><h1>Dashboard</h1><p className="muted">Your business at a glance.</p><div className="cards">{[['Monthly sales',stats.sales],['Outstanding',stats.outstanding],['Products',stats.products],['Customers',stats.customers]].map(x=><div className="card"><span>{x[0]}</span><strong>{typeof x[1]==='number'&&x[0].includes('sales')?money(x[1]):x[1]||0}</strong></div>)}</div><div className="panel"><h2>GSTSaathi is ready</h2><p>Create customers and products, then make your first GST invoice. All records are isolated by business account.</p></div></section>;
 if(tab==='reports')return <section className="content"><h1>Reports</h1><div className="cards"><div className="card"><span>Total sales</span><strong>{money(stats.sales)}</strong></div><div className="card"><span>Receivable</span><strong>{money(stats.receivable)}</strong></div><div className="card"><span>CGST</span><strong>{money(stats.tax?.cgst)}</strong></div><div className="card"><span>SGST</span><strong>{money(stats.tax?.sgst)}</strong></div></div></section>;
 if(tab==='billing')return <Billing/>;
 return <section className="content"><div className="titleRow"><div><h1>{tab[0].toUpperCase()+tab.slice(1)}</h1><p className="muted">Manage your {tab}.</p></div><button className="primary small" onClick={()=>setShow(true)}><Plus size={17}/> Add</button></div><div className="toolbar"><Search size={18}/><input placeholder="Search..." value={q} onChange={e=>setQ(e.target.value)}/></div><div className="tableWrap"><table><thead><tr>{tab==='customers'?<><th>Name</th><th>Phone</th><th>GSTIN</th></>:tab==='products'?<><th>Product</th><th>SKU</th><th>Stock</th><th>GST</th></>:<><th>Invoice</th><th>Customer</th><th>Total</th><th>Status</th></>}</tr></thead><tbody>{rows.filter(r=>JSON.stringify(r).toLowerCase().includes(q.toLowerCase())).map(r=><tr>{tab==='customers'?<><td>{r.name}</td><td>{r.phone||'-'}</td><td>{r.gstin||'-'}</td></>:tab==='products'?<><td>{r.name}</td><td>{r.sku||'-'}</td><td>{r.stock}</td><td>{r.gst_rate}%</td></>:<><td>{r.invoice_no}</td><td>{r.customer_name||'Walk-in'}</td><td>{money(r.total)}</td><td><span className={'status '+r.status}>{r.status}</span></td></>}</tr>)}</tbody></table></div>{show&&<Modal tab={tab} close={()=>{setShow(false);load()}}/>}</section>
}

function Modal({tab,close}){
 const [f,setF]=useState({}),[busy,setBusy]=useState(false);
 const submit=async e=>{e.preventDefault();setBusy(true);try{await api('/'+tab,{method:'POST',body:JSON.stringify(f)});close()}catch(e){alert(e.message)}finally{setBusy(false)}};
 return <div className="overlay"><div className="modal"><h2>Add {tab.slice(0,-1)}</h2><form onSubmit={submit}>{tab==='customers'?<><input required placeholder="Name" onChange={e=>setF({...f,name:e.target.value})}/><input placeholder="Phone" onChange={e=>setF({...f,phone:e.target.value})}/><input placeholder="GSTIN" onChange={e=>setF({...f,gstin:e.target.value})}/><input placeholder="Address" onChange={e=>setF({...f,address:e.target.value})}/></>:<><input required placeholder="Product name" onChange={e=>setF({...f,name:e.target.value})}/><input placeholder="SKU" onChange={e=>setF({...f,sku:e.target.value})}/><input placeholder="HSN/SAC" onChange={e=>setF({...f,hsn_sac:e.target.value})}/><input type="number" placeholder="Price" onChange={e=>setF({...f,price:e.target.value})}/><input type="number" placeholder="GST %" onChange={e=>setF({...f,gst_rate:e.target.value})}/><input type="number" placeholder="Opening stock" onChange={e=>setF({...f,stock:e.target.value})}/></>}<div className="actions"><button type="button" onClick={close}>Cancel</button><button disabled={busy} className="primary">{busy?'Saving...':'Save'}</button></div></form></div></div>
}

function Billing(){const [plan,setPlan]=useState('business');const buy=async()=>{try{const d=await api('/billing/razorpay-order',{method:'POST',body:JSON.stringify({plan})});alert('Razorpay order created: '+d.order.id+'\\nAdd Razorpay Checkout on your production domain to complete payment.')}catch(e){alert(e.message)}};return <section className="content"><h1>Billing</h1><p className="muted">Choose a monthly plan.</p><div className="plans">{[['starter','₹99'],['business','₹149'],['pro','₹249']].map(x=><div className={'plan '+(plan===x[0]?'selected':'')} onClick={()=>setPlan(x[0])}><h2>{x[0]}</h2><strong>{x[1]}<small>/month</small></strong><p>GST invoices, customers, inventory, reports and team features.</p><button className="primary" onClick={buy}>Continue to payment</button></div>)}</div></section>}

createRoot(document.getElementById('root')).render(<App/>);

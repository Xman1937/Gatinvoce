# GSTSaathi

Production-oriented GST billing SaaS starter.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: PostgreSQL (works with Supabase PostgreSQL)
- Auth: JWT + bcrypt
- Payments: Razorpay subscription-ready
- Deployment: Netlify frontend + Render/Railway/Hostinger Node backend

## Features
- Business signup/login
- Business-isolated data
- Dashboard
- Customers CRUD
- Products/inventory CRUD
- GST invoices
- Payments
- Reports
- Invoice HTML printing / PDF via browser print
- Team roles
- Razorpay subscription checkout endpoint
- 30-day trial fields
- Responsive mobile-first UI

## Run locally

### Backend
```bash
cd server
cp .env.example .env
npm install
npm run migrate
npm run dev
```

### Frontend
```bash
cd client
npm install
cp .env.example .env
npm run dev
```

Set `VITE_API_URL=http://localhost:5000/api`.

For Supabase, use the PostgreSQL connection string from Supabase in `DATABASE_URL`. Never expose database credentials in the frontend.

## Important
Razorpay keys and JWT secret belong only in backend environment variables.

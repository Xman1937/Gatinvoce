import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import Razorpay from 'razorpay';
const { Pool } = pg;

const app = express();
app.use(cors({origin: process.env.FRONTEND_URL?.split(',') || true}));
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('supabase') ? {rejectUnauthorized:false} : undefined
});

const sign = u => jwt.sign({id:u.id,businessId:u.business_id,role:u.role}, process.env.JWT_SECRET, {expiresIn:'7d'});
function auth(req,res,next){
  try {
    const token=(req.headers.authorization||'').replace('Bearer ','');
    const p=jwt.verify(token,process.env.JWT_SECRET);
    req.user=p; next();
  } catch { res.status(401).json({error:'Unauthorized'}); }
}
function owner(req,res,next){ if(!['owner','admin'].includes(req.user.role)) return res.status(403).json({error:'Admin access required'}); next(); }
const q = (text, params=[]) => pool.query(text,params);

app.get('/api/health',(req,res)=>res.json({ok:true,service:'GSTSaathi API'}));

app.post('/api/auth/signup', async (req,res)=>{
  const {businessName,name,email,password,gstin,phone}=req.body;
  if(!businessName||!name||!email||!password) return res.status(400).json({error:'Business name, name, email and password are required'});
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const exists=await client.query('SELECT id FROM users WHERE email=$1',[email.toLowerCase()]);
    if(exists.rowCount) throw new Error('Email already registered');
    const b=await client.query('INSERT INTO businesses(name,gstin,phone,email) VALUES($1,$2,$3,$4) RETURNING *',[businessName,gstin||null,phone||null,email.toLowerCase()]);
    const hash=await bcrypt.hash(password,12);
    const u=await client.query('INSERT INTO users(business_id,name,email,password_hash,role) VALUES($1,$2,$3,$4,$5) RETURNING id,business_id,name,email,role',[b.rows[0].id,name,email.toLowerCase(),hash,'owner']);
    await client.query('COMMIT');
    res.json({token:sign(u.rows[0]),user:u.rows[0],business:b.rows[0]});
  }catch(e){await client.query('ROLLBACK');res.status(400).json({error:e.message});}finally{client.release();}
});

app.post('/api/auth/login', async(req,res)=>{
  const {email,password}=req.body;
  const r=await q('SELECT * FROM users WHERE email=$1',[email?.toLowerCase()]);
  if(!r.rowCount || !(await bcrypt.compare(password,r.rows[0].password_hash))) return res.status(401).json({error:'Invalid email or password'});
  const u=r.rows[0]; const b=(await q('SELECT * FROM businesses WHERE id=$1',[u.business_id])).rows[0];
  res.json({token:sign(u),user:{id:u.id,business_id:u.business_id,name:u.name,email:u.email,role:u.role},business:b});
});

app.get('/api/me',auth,async(req,res)=>{
 const u=(await q('SELECT id,business_id,name,email,role FROM users WHERE id=$1',[req.user.id])).rows[0];
 const b=(await q('SELECT * FROM businesses WHERE id=$1',[req.user.businessId])).rows[0];
 res.json({user:u,business:b});
});

app.get('/api/dashboard',auth,async(req,res)=>{
 const b=req.user.businessId;
 const [sales,outstanding,products,customers,inv] = await Promise.all([
   q(`SELECT COALESCE(SUM(total),0) total FROM invoices WHERE business_id=$1 AND invoice_date>=date_trunc('month',current_date)`,[b]),
   q(`SELECT COALESCE(SUM(total-paid),0) total FROM invoices WHERE business_id=$1 AND status IN ('unpaid','part_paid')`,[b]),
   q('SELECT COUNT(*) FROM products WHERE business_id=$1',[b]),
   q('SELECT COUNT(*) FROM customers WHERE business_id=$1',[b]),
   q('SELECT COUNT(*) FROM invoices WHERE business_id=$1',[b])
 ]);
 res.json({sales:sales.rows[0].total,outstanding:outstanding.rows[0].total,products:products.rows[0].count,customers:customers.rows[0].count,invoices:inv.rows[0].count});
});

const crud = (path, table, cols) => {
 app.get(`/api/${path}`,auth,async(req,res)=>{
  const r=await q(`SELECT * FROM ${table} WHERE business_id=$1 ORDER BY created_at DESC`,[req.user.businessId]); res.json(r.rows);
 });
 app.post(`/api/${path}`,auth,async(req,res)=>{
  const vals=cols.map(c=>req.body[c]??null); const placeholders=vals.map((_,i)=>`$${i+2}`).join(',');
  const r=await q(`INSERT INTO ${table}(business_id,${cols.join(',')}) VALUES($1,${placeholders}) RETURNING *`,[req.user.businessId,...vals]); res.json(r.rows[0]);
 });
 app.put(`/api/${path}/:id`,auth,async(req,res)=>{
  const vals=cols.map(c=>req.body[c]??null); const sets=cols.map((c,i)=>`${c}=$${i+2}`).join(',');
  const r=await q(`UPDATE ${table} SET ${sets} WHERE id=$1 AND business_id=$${cols.length+2} RETURNING *`,[req.params.id,...vals,req.user.businessId]);
  if(!r.rowCount) return res.status(404).json({error:'Not found'}); res.json(r.rows[0]);
 });
 app.delete(`/api/${path}/:id`,auth,owner,async(req,res)=>{
  const r=await q(`DELETE FROM ${table} WHERE id=$1 AND business_id=$2`,[req.params.id,req.user.businessId]);
  res.json({ok:r.rowCount>0});
 });
};
crud('customers','customers',['name','phone','email','gstin','address','state_code']);
crud('products','products',['name','sku','hsn_sac','unit','price','gst_rate','stock','low_stock']);

app.get('/api/invoices',auth,async(req,res)=>{
 const r=await q(`SELECT i.*,c.name customer_name FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE i.business_id=$1 ORDER BY i.created_at DESC`,[req.user.businessId]); res.json(r.rows);
});

app.post('/api/invoices',auth,async(req,res)=>{
 const {customer_id,invoice_date,due_date,discount=0,notes,items=[]}=req.body;
 if(!items.length) return res.status(400).json({error:'At least one item is required'});
 const client=await pool.connect();
 try{
  await client.query('BEGIN');
  const n=await client.query(`SELECT COALESCE(MAX(NULLIF(regexp_replace(invoice_no,'\\D','','g'),'')::int),0)+1 n FROM invoices WHERE business_id=$1`,[req.user.businessId]);
  const invoice_no='INV-'+String(n.rows[0].n).padStart(4,'0');
  let subtotal=0,cgst=0,sgst=0,igst=0;
  for(const it of items){
    const taxable=Number(it.qty)*Number(it.rate); subtotal+=taxable;
    const tax=taxable*Number(it.gst_rate||0)/100;
    if(it.same_state===false) igst+=tax; else {cgst+=tax/2;sgst+=tax/2;}
  }
  const total=subtotal-Number(discount||0)+cgst+sgst+igst;
  const inv=await client.query(`INSERT INTO invoices(business_id,customer_id,invoice_no,invoice_date,due_date,subtotal,discount,cgst,sgst,igst,total,notes) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,[req.user.businessId,customer_id||null,invoice_no,invoice_date||new Date(),due_date||null,subtotal,discount,cgst,sgst,igst,total,notes||null]);
  for(const it of items){
    const taxable=Number(it.qty)*Number(it.rate);
    await client.query(`INSERT INTO invoice_items(invoice_id,product_id,description,qty,rate,gst_rate,taxable) VALUES($1,$2,$3,$4,$5,$6,$7)`,[inv.rows[0].id,it.product_id||null,it.description,it.qty,it.rate,it.gst_rate||0]);
    if(it.product_id) {
      await client.query(`UPDATE products SET stock=stock-$1 WHERE id=$2 AND business_id=$3`,[it.qty,it.product_id,req.user.businessId]);
      await client.query(`INSERT INTO stock_movements(business_id,product_id,qty,movement_type,reference_id) VALUES($1,$2,$3,$4,$5)`,[req.user.businessId,it.product_id,-Number(it.qty),'sale',inv.rows[0].id]);
    }
  }
  await client.query('COMMIT'); res.json(inv.rows[0]);
 }catch(e){await client.query('ROLLBACK');res.status(400).json({error:e.message});}finally{client.release();}
});

app.get('/api/invoices/:id',auth,async(req,res)=>{
 const i=await q(`SELECT i.*,c.name customer_name,c.gstin customer_gstin,c.address customer_address,c.state_code customer_state FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE i.id=$1 AND i.business_id=$2`,[req.params.id,req.user.businessId]);
 if(!i.rowCount)return res.status(404).json({error:'Not found'});
 const items=await q('SELECT * FROM invoice_items WHERE invoice_id=$1 ORDER BY created_at',[req.params.id]);
 res.json({...i.rows[0],items:items.rows});
});

app.post('/api/invoices/:id/payments',auth,async(req,res)=>{
 const {amount,method,note}=req.body;
 const client=await pool.connect();
 try{
  await client.query('BEGIN');
  const i=await client.query('SELECT * FROM invoices WHERE id=$1 AND business_id=$2 FOR UPDATE',[req.params.id,req.user.businessId]);
  if(!i.rowCount) throw new Error('Invoice not found');
  await client.query('INSERT INTO payments(business_id,invoice_id,amount,method,note) VALUES($1,$2,$3,$4,$5)',[req.user.businessId,req.params.id,amount,method,note||null]);
  const paid=Number(i.rows[0].paid)+Number(amount); const total=Number(i.rows[0].total);
  const status=paid>=total?'paid':paid>0?'part_paid':'unpaid';
  const u=await client.query('UPDATE invoices SET paid=$1,status=$2 WHERE id=$3 RETURNING *',[paid,status,req.params.id]);
  await client.query('COMMIT'); res.json(u.rows[0]);
 }catch(e){await client.query('ROLLBACK');res.status(400).json({error:e.message});}finally{client.release();}
});

app.get('/api/reports/summary',auth,async(req,res)=>{
 const b=req.user.businessId;
 const [sales,purchases,receivable,tax] = await Promise.all([
  q(`SELECT COALESCE(SUM(total),0) total FROM invoices WHERE business_id=$1`,[b]),
  q(`SELECT 0 total`),
  q(`SELECT COALESCE(SUM(total-paid),0) total FROM invoices WHERE business_id=$1 AND status IN ('unpaid','part_paid')`,[b]),
  q(`SELECT COALESCE(SUM(cgst),0) cgst,COALESCE(SUM(sgst),0) sgst,COALESCE(SUM(igst),0) igst FROM invoices WHERE business_id=$1`,[b])
 ]);
 res.json({sales:sales.rows[0].total,purchases:purchases.rows[0].total,receivable:receivable.rows[0].total,tax:tax.rows[0]});
});

app.post('/api/billing/razorpay-order',auth,async(req,res)=>{
 const {plan='business'}=req.body;
 if(!process.env.RAZORPAY_KEY_ID||!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({error:'Razorpay is not configured'});
 const amount={starter:9900,business:14900,pro:24900}[plan];
 if(!amount)return res.status(400).json({error:'Invalid plan'});
 const rz=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
 const order=await rz.orders.create({amount,currency:'INR',receipt:`${req.user.businessId}-${Date.now()}`,notes:{businessId:req.user.businessId,plan}});
 res.json({keyId:process.env.RAZORPAY_KEY_ID,order,plan});
});

app.listen(process.env.PORT||5000,()=>console.log(`GSTSaathi API running on ${process.env.PORT||5000}`));

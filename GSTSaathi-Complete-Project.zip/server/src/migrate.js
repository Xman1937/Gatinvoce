import 'dotenv/config';
import pg from 'pg';
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('supabase') ? {rejectUnauthorized:false} : undefined });

const sql = `
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS businesses (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL,
 gstin text,
 phone text,
 email text,
 address text,
 state_code text,
 trial_ends_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
 plan text NOT NULL DEFAULT 'free',
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 name text NOT NULL,
 email text NOT NULL UNIQUE,
 password_hash text NOT NULL,
 role text NOT NULL DEFAULT 'owner' CHECK (role IN ('owner','admin','staff')),
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 name text NOT NULL,
 phone text,
 email text,
 gstin text,
 address text,
 state_code text,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 name text NOT NULL,
 sku text,
 hsn_sac text,
 unit text NOT NULL DEFAULT 'pcs',
 price numeric(14,2) NOT NULL DEFAULT 0,
 gst_rate numeric(5,2) NOT NULL DEFAULT 0,
 stock numeric(14,3) NOT NULL DEFAULT 0,
 low_stock numeric(14,3) NOT NULL DEFAULT 5,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invoices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
 invoice_no text NOT NULL,
 invoice_date date NOT NULL DEFAULT CURRENT_DATE,
 due_date date,
 status text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid','part_paid','paid','cancelled')),
 subtotal numeric(14,2) NOT NULL DEFAULT 0,
 discount numeric(14,2) NOT NULL DEFAULT 0,
 cgst numeric(14,2) NOT NULL DEFAULT 0,
 sgst numeric(14,2) NOT NULL DEFAULT 0,
 igst numeric(14,2) NOT NULL DEFAULT 0,
 total numeric(14,2) NOT NULL DEFAULT 0,
 paid numeric(14,2) NOT NULL DEFAULT 0,
 notes text,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(business_id, invoice_no)
);

CREATE TABLE IF NOT EXISTS invoice_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
 product_id uuid REFERENCES products(id) ON DELETE SET NULL,
 description text NOT NULL,
 qty numeric(14,3) NOT NULL,
 rate numeric(14,2) NOT NULL,
 gst_rate numeric(5,2) NOT NULL DEFAULT 0,
 taxable numeric(14,2) NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
 amount numeric(14,2) NOT NULL,
 method text NOT NULL CHECK (method IN ('cash','upi','bank','card','cheque')),
 paid_at timestamptz NOT NULL DEFAULT now(),
 note text
);

CREATE TABLE IF NOT EXISTS stock_movements (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
 qty numeric(14,3) NOT NULL,
 movement_type text NOT NULL,
 reference_id uuid,
 created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_business ON users(business_id);
CREATE INDEX IF NOT EXISTS idx_customers_business ON customers(business_id);
CREATE INDEX IF NOT EXISTS idx_products_business ON products(business_id);
CREATE INDEX IF NOT EXISTS idx_invoices_business ON invoices(business_id);
CREATE INDEX IF NOT EXISTS idx_payments_business ON payments(business_id);
`;
await pool.query(sql);
console.log('GSTSaathi database ready');
await pool.end();
